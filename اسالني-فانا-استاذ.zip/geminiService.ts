import { GoogleGenAI, Type, Schema } from "@google/genai";
import { Difficulty, SchoolLevel, SectionType, Subject, Question } from './types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const questionSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    questions: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          text: { type: Type.STRING, description: "The question text in Arabic (or target language for FL)." },
          options: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING },
            description: "Array of exactly 3 options."
          },
          correctAnswer: { type: Type.STRING, description: "The correct answer text, must be one of the options." },
          explanation: { type: Type.STRING, description: "Brief explanation of why it is correct." },
          type: { type: Type.STRING, enum: ["written", "oral_scenario"], description: "Whether it is a standard written question or a scenario typically asked in oral exams." }
        },
        required: ["text", "options", "correctAnswer", "type"]
      }
    }
  }
};

export const generateQuestions = async (
  section: SectionType,
  level: SchoolLevel,
  difficulty: Difficulty,
  subject?: Subject
): Promise<Question[]> => {
  
  const model = 'gemini-2.5-flash';
  
  let promptContext = `
    You are an expert examiner for Algerian Teacher Recruitment Contests (مسابقة الأساتذة).
    Target Audience: Teachers for ${level} School Level.
    Topic: ${section}.
    ${subject ? `Subject Specialization: ${subject}` : ''}
    Difficulty: ${difficulty}.
    Language: Arabic (unless the subject is French or English, then use the target language for the content, but instructions in Arabic).
  `;

  let specificInstructions = "";

  if (section === SectionType.DIDACTICS) {
    specificInstructions = `
      Focus on ${subject} didactics (تعليمية المادة).
      Questions must be from the official Algerian curriculum for ${level} and University level concepts relevant to teaching.
      For ${Subject.MATH} or ${Subject.PHYSICS}, include questions on functions, mechanics, etc., appropriate for a teacher's knowledge.
      Include both theoretical questions and practical classroom scenarios.
    `;
  } else if (section === SectionType.LEGISLATION) {
    specificInstructions = `
      Focus on School Legislation (التشريع المدرسي) in Algeria.
      Include questions about rights, duties, laws, councils, and administrative procedures.
      These should be common questions found in previous contests.
    `;
  } else if (section === SectionType.PSYCHOLOGY) {
    specificInstructions = `
      Focus on Educational Psychology (علم النفس التربوي).
      Theories of learning, child development, classroom management psychology.
    `;
  }

  const prompt = `
    ${promptContext}
    ${specificInstructions}
    
    Generate exactly 10 unique, high-quality multiple-choice questions.
    Each question must have 3 options. Only one is correct.
    For 'Oral' type questions, describe a scenario a jury might ask.
    Ensure questions are not trivial. They should test a teacher's competence.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: questionSchema,
        systemInstruction: "You are a strict and professional Algerian education expert.",
        temperature: 0.7 
      }
    });

    const text = response.text;
    if (!text) throw new Error("No data returned");

    const data = JSON.parse(text);
    
    // Add IDs and shuffle options roughly (though frontend can shuffle too)
    return data.questions.map((q: any, index: number) => ({
      ...q,
      id: `${section}-${Date.now()}-${index}`
    }));

  } catch (error) {
    console.error("GenAI Error:", error);
    // Fallback/Mock data could be added here if API fails, but we will return empty to handle in UI
    throw error;
  }
};
