export enum SchoolLevel {
  PRIMARY = 'ابتدائي',
  MIDDLE = 'متوسط',
  SECONDARY = 'ثانوي'
}

export enum Subject {
  MATH = 'رياضيات',
  ARABIC = 'لغة عربية',
  PHYSICS = 'فيزياء',
  FRENCH = 'فرنسية',
  ENGLISH = 'انجليزية',
  SCIENCE = 'علوم طبيعية',
  SOCIAL = 'اجتماعيات'
}

export enum SectionType {
  DIDACTICS = 'تعليمية المادة',
  LEGISLATION = 'تشريع مدرسي',
  PSYCHOLOGY = 'علم النفس التربوي'
}

export enum Difficulty {
  EASY = 'سهل',
  MEDIUM = 'متوسط',
  HARD = 'صعب'
}

export interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: string;
  explanation?: string;
  type: 'written' | 'oral_scenario';
}

export interface QuizSession {
  score: number;
  totalQuestions: number;
  currentQuestionIndex: number;
  questions: Question[];
  isActive: boolean;
  difficulty: Difficulty;
  timeLeft: number; // in seconds
}

export interface UserProgress {
  didactics: { [key in Difficulty]: number }; // High score
  legislation: { [key in Difficulty]: number };
  psychology: { [key in Difficulty]: number };
}

export interface User {
  name: string;
  schoolLevel: SchoolLevel | null;
}
